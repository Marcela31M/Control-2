from utiles.db import db


class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    buyer = db.Column(db.String(50), nullable=False)
    seller = db.Column(db.Integer, nullable=False)
    totalSale = db.Column(db.Integer, nullable=False)
    date = db.Column(db.String(50), nullable=True)
    discount = db.Column(db.Integer, nullable=False)
    tax = db.Column(db.Integer, nullable=False)

    def __init__(
        self, buyer, seller, tax, discount, totalSale=0, date=None
    ) -> None:
        self.buyer = buyer
        self.totalSale = totalSale
        self.date = date
        self.seller = seller
        self.tax = tax
        self.discount = discount


from flask import Blueprint, render_template, redirect, url_for
from flask_login import current_user, login_required
from forms.orderCreateForm import OrderCreateForm
from models.orderdetail import OrderDetail
from utiles.db import db
from models.order import Order
from datetime import datetime

orders = Blueprint("orders", __name__, url_prefix="/orders")


@orders.route("/")
@login_required
def home():
    orderList = Order.query.all()
    return render_template("orders/home.html", items=orderList, user=current_user)


@orders.route("/create", methods=["GET", "POST"])
@login_required
def create():
    form = OrderCreateForm()
    if form.validate_on_submit():
        buyer = form.buyer.data
        tax = form.tax.data
        discount = form.discount.data
        newOrder = Order(buyer, current_user.id, tax, discount, 0, datetime.today())
        db.session.add(newOrder)
        db.session.commit()
        return redirect(url_for("orders.home"))
    return render_template("orders/create.html", form=form)


@orders.route("/update_order/<int:id_order>", methods=["GET", "POST"])
@login_required
def update(id_order):
    form = OrderCreateForm()
    order = Order.query.get(id_order)
    if form.validate_on_submit():
        buyer = form.buyer.data
        tax = form.tax.data
        discount = form.discount.data
        order.discount = discount
        order.tax = tax
        order.buyer = buyer
        db.session.add(order)
        db.session.commit()
        return redirect(url_for("orders.home"))
    form.discount.data = order.discount
    form.tax.data = order.tax
    form.buyer.data = order.buyer
    return render_template("orders/update.html", form=form, id_order=id_order)


@orders.route("/delete_order/<int:id_order>", methods=["GET", "POST"])
@login_required
def delete(id_order):
    order = Order.query.get(id_order)
    details = OrderDetail.query.filter_by(orderId=id_order)
    for order_detail in details:
        db.session.delete(order_detail)
    db.session.delete(order)
    db.session.commit()
    return redirect(url_for("orders.home"))


@orders.route("/crear_reporte/<int:orderId>", methods=["GET", "POST"])
@login_required
def reporte(orderId):
    order = Order.query.get(orderId)
    discount_total = order.totalSale * (1 - order.discount / 100)
    total = discount_total * (1 + order.tax / 100)
    return render_template("orders/reporte.html", totalSale = order.totalSale, total=total, discount_total = discount_total)


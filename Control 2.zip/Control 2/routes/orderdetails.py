from flask import Blueprint, render_template, redirect, url_for
from flask_login import current_user, login_required
from forms.orderDetailCreateForm import OrderDetailCreateForm
from utiles.db import db
from models.order import Order
from models.orderdetail import OrderDetail

orderDetails = Blueprint("orderDetails", __name__, url_prefix="/orderDetails")


@orderDetails.route("/")
@login_required
def home():
    return render_template("orderDetails/home.html", user=current_user)


@orderDetails.route("/<int:orderId>")
@login_required
def homeByOrderId(orderId):
    currentOrder = Order.query.filter_by(id=orderId).first()
    orderDetailList = OrderDetail.query.filter_by(orderId=orderId).all()
    return render_template("orderDetails/home.html", order=currentOrder, user=current_user, items=orderDetailList)


@orderDetails.route("/create", methods=["GET", "POST"])
@login_required
def create():
    form = OrderDetailCreateForm()
    if form.validate_on_submit():
        orderId = form.orderId.data
        currentOrder = Order.query.filter_by(id=orderId).first()

        quantity = form.quantity.data
        description = form.description.data
        unitCost = form.unitCost.data
        totalCost = quantity * unitCost
        currentOrder.totalSale += totalCost

        newOrderDetail = OrderDetail(orderId, quantity, description, unitCost, totalCost)
        db.session.add(newOrderDetail)
        db.session.add(currentOrder)
        db.session.commit()
        return redirect(url_for("orderDetails.home"))
    return render_template("orderDetails/create.html", form=form)


@orderDetails.route("/create/<int:orderId>", methods=["GET", "POST"])
@login_required
def createByOrderId(orderId):
    form = OrderDetailCreateForm(orderId=orderId)
    if form.validate_on_submit():
        currentOrder = Order.query.filter_by(id=orderId).first()

        quantity = form.quantity.data
        description = form.description.data
        unitCost = form.unitCost.data
        totalCost = quantity * unitCost
        currentOrder.totalSale += totalCost

        newOrderDetail = OrderDetail(orderId, quantity, description, unitCost, totalCost)
        db.session.add(newOrderDetail)
        db.session.add(currentOrder)
        db.session.commit()
        return redirect(url_for("orderDetails.homeByOrderId", orderId=orderId))
    return render_template("orderDetails/create.html", form=form, user=current_user, orderId=orderId)


@orderDetails.route("/update/<int:idOrderDetail>", methods=["GET", "POST"])
@login_required
def update(idOrderDetail):
    form = OrderDetailCreateForm()
    detail = OrderDetail.query.get(idOrderDetail)
    if form.validate_on_submit():
        orderId = form.orderId.data
        currentOrder = Order.query.get(orderId)
        detail.quantity = form.quantity.data
        detail.description = form.description.data
        detail.unitCost = form.unitCost.data
        costo_previo= detail.totalCost
        detail.totalCost = detail.quantity * detail.unitCost
        currentOrder.totalSale += detail.totalCost - costo_previo

        db.session.add(detail)
        db.session.add(currentOrder)
        db.session.commit()
        return redirect(url_for("orderDetails.homeByOrderId", orderId=detail.orderId))
    form.unitCost.data = detail.unitCost 
    form.quantity.data = detail.quantity 
    form.description.data = detail.description
    form.quantity.data = detail.quantity
    form.orderId.data = detail.orderId
    return render_template("orderDetails/update.html", form=form, idOrderDetail=idOrderDetail)


@orderDetails.route("/delete/<int:idOrderDetail>", methods=["GET", "POST"])
@login_required
def delete(idOrderDetail):
    detail = OrderDetail.query.get(idOrderDetail)
    order = detail.orderId
    currentOrder = Order.query.get(detail.orderId)
    currentOrder.totalSale -= detail.totalCost
    db.session.delete(detail)
    db.session.add(currentOrder)
    db.session.commit()
    return redirect(url_for("orderDetails.homeByOrderId", orderId=order))

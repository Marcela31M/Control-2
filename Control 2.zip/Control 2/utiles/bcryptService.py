from flask_bcrypt import Bcrypt

bcrypt = Bcrypt()
